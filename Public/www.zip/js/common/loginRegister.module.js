(function() {
  'use strict';

  angular
    .module('loginRegister',[
      'ionic'
    ])
}());
